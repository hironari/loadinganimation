window.onload = function() {
    const spinner = document.getElementById('loading');
   
    // Add .loaded to .loading
    spinner.classList.add('loaded');
  }